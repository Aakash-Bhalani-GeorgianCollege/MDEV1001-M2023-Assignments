package com.assignment.mdev1001_m2023_assignment4.extension

object AppConstants {
    const val TOKEN = "TOKEN"
}